import React from 'react';
import { Redirect, router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@clerk/expo';
import { useColors } from '@/hooks/useColors';

export default function WelcomeScreen() {
  const { isSignedIn } = useAuth();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  if (isSignedIn) return <Redirect href="/(tabs)" />;

  return (
    <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top + 24, paddingBottom: insets.bottom + 18 }]}>
      <View style={styles.topRow}>
        <View style={[styles.logoMark, { backgroundColor: colors.navy }]}><Feather name="star" size={22} color={colors.coral} /></View>
        <Text style={[styles.wordmark, { color: colors.ink }]}>lumina</Text>
        <View style={styles.topSpacer} />
        <View style={[styles.statusPill, { backgroundColor: colors.secondary }]}><View style={[styles.statusDot, { backgroundColor: colors.green }]} /><Text style={[styles.statusText, { color: colors.secondaryForeground }]}>Gemini ready</Text></View>
      </View>

      <View style={styles.hero}>
        <View style={[styles.orbit, { borderColor: colors.sky }]}><View style={[styles.orbitInner, { backgroundColor: colors.navy }]}><Feather name="zap" size={44} color={colors.coral} /></View></View>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>YOUR THOUGHT PARTNER</Text>
        <Text style={[styles.title, { color: colors.ink }]}>Think clearer.{'\n'}Move faster.</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Lumina turns big ideas into clear next steps, thoughtful words, and momentum you can feel.</Text>
      </View>

      <View style={styles.benefits}>
        {([['message-circle', 'A smarter conversation'], ['layers', 'Tools for every kind of work'], ['lock', 'Private by design']] as const).map(([icon, label]) => (
          <View key={label} style={styles.benefitRow}><View style={[styles.benefitIcon, { backgroundColor: colors.card }]}><Feather name={icon} size={16} color={colors.primary} /></View><Text style={[styles.benefitText, { color: colors.foreground }]}>{label}</Text></View>
        ))}
      </View>

      <View style={styles.actions}>
        <Pressable testID="get-started" onPress={() => router.push('/sign-up' as never)} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary, opacity: pressed ? 0.86 : 1 }]}><Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>Create your account</Text><Feather name="arrow-up-right" size={19} color={colors.primaryForeground} /></Pressable>
        <Pressable testID="sign-in" onPress={() => router.push('/sign-in' as never)} style={({ pressed }) => [styles.secondaryButton, { borderColor: colors.border, backgroundColor: colors.card, opacity: pressed ? 0.7 : 1 }]}><Text style={[styles.secondaryButtonText, { color: colors.ink }]}>I already have an account</Text></Pressable>
        <Text style={[styles.legal, { color: colors.mutedForeground }]}>By continuing, you agree to Lumina's Terms and Privacy Policy.</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 24 },
  topRow: { flexDirection: 'row', alignItems: 'center', minHeight: 42 },
  topSpacer: { flex: 1 },
  logoMark: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginRight: 9 },
  wordmark: { fontSize: 20, fontWeight: '700', letterSpacing: -0.6 },
  statusPill: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 7, borderRadius: 99, gap: 6 },
  statusDot: { width: 7, height: 7, borderRadius: 7 },
  statusText: { fontSize: 11, fontWeight: '600' },
  hero: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingBottom: 20 },
  orbit: { width: 142, height: 142, borderRadius: 80, borderWidth: 1, alignItems: 'center', justifyContent: 'center', marginBottom: 38 },
  orbitInner: { width: 94, height: 94, borderRadius: 32, alignItems: 'center', justifyContent: 'center', transform: [{ rotate: '12deg' }] },
  eyebrow: { fontSize: 11, fontWeight: '700', letterSpacing: 2, marginBottom: 14 },
  title: { fontSize: 44, lineHeight: 48, fontWeight: '700', letterSpacing: -1.8, textAlign: 'center' },
  subtitle: { maxWidth: 330, fontSize: 16, lineHeight: 24, textAlign: 'center', marginTop: 18 },
  benefits: { gap: 12, marginBottom: 26 },
  benefitRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  benefitIcon: { width: 32, height: 32, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  benefitText: { fontSize: 14, fontWeight: '500' },
  actions: { gap: 12 },
  primaryButton: { height: 56, borderRadius: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  primaryButtonText: { fontSize: 15, fontWeight: '700' },
  secondaryButton: { height: 56, borderRadius: 18, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  secondaryButtonText: { fontSize: 15, fontWeight: '600' },
  legal: { textAlign: 'center', fontSize: 11, lineHeight: 16, paddingHorizontal: 18, marginTop: 2 },
});